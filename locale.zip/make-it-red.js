
/**
 * make-it-red.js - Main implementation file for the "Make It Red" Zotero plugin
 * 
 * This file contains the core functionality of the plugin, including:
 * - UI modification methods (adding/removing elements to Zotero)
 * - Feature implementation (toggle colors, display messages)
 * - Utility methods for plugin operation
 */

// Define the global MakeItRed object that contains all plugin functionality
MakeItRed = {
	// Plugin metadata (populated by init method)
	id: null,           // Plugin ID
	version: null,      // Plugin version
	rootURI: null,      // URI to the plugin's directory
	initialized: false, // Flag to prevent double initialization
	
	// Track DOM elements added by this plugin for later cleanup
	addedElementIDs: [],
	
	/**
	 * Initialize the plugin with metadata
	 * Called by bootstrap.js during startup
	 * 
	
	 */
	init({ id, version, rootURI }) {
		if (this.initialized) return; // Prevent double initialization
		this.id = id;
		this.version = version;
		this.rootURI = rootURI;
		this.initialized = true;
	},
	
	/**
	 * Utility function to log messages to Zotero's debug console
	 */
	log(msg) {
		Zotero.debug("Make It Red: " + msg);
	},
	
	/**
	 * Add plugin UI elements to a Zotero window
	 */
	addToWindow(window) {
		let doc = window.document;
		
		// Add a stylesheet to the main Zotero pane
		// This CSS file controls the visual appearance of our plugin
		let link1 = doc.createElement('link');
		link1.id = 'make-it-red-stylesheet';
		link1.type = 'text/css';
		link1.rel = 'stylesheet';
		link1.href = this.rootURI + 'style.css';
		doc.documentElement.appendChild(link1);
		this.storeAddedElement(link1); // Track for cleanup later
		
		// Use Fluent for localization (allows translating UI elements)
		// This loads our .ftl file with translated strings
		window.MozXULElement.insertFTLIfNeeded("make-it-red.ftl");
		
		// Add menu option for green toggle
		// This creates a checkbox menu item in Zotero's View menu
		let menuitem = doc.createXULElement('menuitem');
		menuitem.id = 'make-it-green-instead';
		menuitem.setAttribute('type', 'checkbox');
		// Connect to localized string from .ftl file
		menuitem.setAttribute('data-l10n-id', 'make-it-red-green-instead');
		// Add event listener to call our toggle function when clicked
		menuitem.addEventListener('command', () => {
			MakeItRed.toggleGreen(window, menuitem.checked);
		});
		// Add the menu item to Zotero's View menu
		doc.getElementById('menu_viewPopup').appendChild(menuitem);
		this.storeAddedElement(menuitem); // Track for cleanup later
		
		// Add new menu option for Hello message
		// This creates a regular menu item (not checkbox) in Zotero's View menu
		let helloMenuItem = doc.createXULElement('menuitem');
		helloMenuItem.id = 'make-it-red-hello';
		// Connect to localized string from .ftl file
		helloMenuItem.setAttribute('data-l10n-id', 'make-it-red-hello');
		// Add event listener to call our message function when clicked
		helloMenuItem.addEventListener('command', () => {
			this.showHelloMessage(window);
		});
		// Add the menu item to Zotero's View menu
		doc.getElementById('menu_viewPopup').appendChild(helloMenuItem);
		this.storeAddedElement(helloMenuItem); // Track for cleanup later
	},
	
	/**
	 * Add plugin UI elements to all open Zotero windows
	 * Called during plugin startup
	 */
	addToAllWindows() {
		// Get all open Zotero windows
		var windows = Zotero.getMainWindows();
		for (let win of windows) {
			// Only add to windows that have a Zotero pane
			if (!win.ZoteroPane) continue;
			this.addToWindow(win);
		}
	},
	
	/**
	 * Store a reference to a DOM element added by the plugin
	 * Used for later cleanup when plugin is disabled/uninstalled
	 */
	storeAddedElement(elem) {
		if (!elem.id) {
			throw new Error("Element must have an id");
		}
		this.addedElementIDs.push(elem.id);
	},
	
	/**
	 * Remove all plugin UI elements from a Zotero window
	 */
	removeFromWindow(window) {
		var doc = window.document;
		// Remove all elements that were tracked with storeAddedElement
		for (let id of this.addedElementIDs) {
			doc.getElementById(id)?.remove();
		}
		// Remove the localization resource link
		doc.querySelector('[href="make-it-red.ftl"]').remove();
	},
	
	/**
	 * Remove plugin UI elements from all open Zotero windows
	 * Called during plugin shutdown
	 */
	removeFromAllWindows() {
		var windows = Zotero.getMainWindows();
		for (let win of windows) {
			if (!win.ZoteroPane) continue;
			this.removeFromWindow(win);
		}
	},
	
	/**
	 * Toggle the "green instead" mode ON or OFF
	 * This is triggered by the checkbox menu item
	 * 
	 
	 */
	toggleGreen(window, enabled) {
		// Add or remove a data attribute that CSS can use to change styles
		window.document.documentElement
			.toggleAttribute('data-green-instead', enabled);
	},
	
	/**
	 * Display a hello message in an alert dialog
	 * This is triggered by the "Show Hello Message" menu item
	 * 
	 */
	showHelloMessage(window) {
		// Show the Hello message using the browser's built-in alert dialog
		window.alert("Hello");
		this.log("Hello message displayed");
	},
	
	/**
	 * Main plugin functionality
	 * Called during plugin startup after initialization
	 */
	async main() {
		// Example of using global browser APIs in Zotero 7
		var host = new URL('https://foo.com/path').host;
		this.log(`Host is ${host}`);
		
		// Example of accessing Zotero's preference system
		// This gets a preference value with a default of 'true'
		this.log(`Intensity is ${Zotero.Prefs.get('extensions.make-it-red.intensity', true)}`);
	},
};
