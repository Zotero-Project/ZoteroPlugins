
/**
 * bootstrap.js - Entry point for the "Make It Red" Zotero plugin
 * 
 * This file contains the plugin lifecycle functions that Zotero calls:
 * - install: Called when the plugin is first installed
 * - startup: Called when Zotero starts or when the plugin is enabled
 * - shutdown: Called when Zotero shuts down or when the plugin is disabled
 * - uninstall: Called when the plugin is uninstalled
 * 
 * It also contains window lifecycle hooks:
 * - onMainWindowLoad: Called when a new Zotero window is opened
 * - onMainWindowUnload: Called when a Zotero window is closed
 */

// Global variable that will hold the MakeItRed object imported from make-it-red.js
var MakeItRed;

/**
 * Utility function to log messages to Zotero's debug console
 */
function log(msg) {
	Zotero.debug("Make It Red: " + msg);
}

/**
 * Called when the plugin is installed
 */
function install() {
	log("Installed 2.0");
}

/**
 * Called when Zotero starts or when the plugin is enabled
 * This is the main entry point for initializing the plugin
 * 
 
 */
async function startup({ id, version, rootURI }) {
	log("Starting 2.0");
	
	// Register the plugin's preference pane so users can configure it
	Zotero.PreferencePanes.register({
		pluginID: 'make-it-red@example.com',
		src: rootURI + 'preferences.xhtml', // The XHTML file that defines the preference UI
		scripts: [rootURI + 'preferences.js'] // JavaScript for the preference UI
	});
	
	// Load the main plugin code from make-it-red.js
	Services.scriptloader.loadSubScript(rootURI + 'make-it-red.js');
	
	// Initialize the MakeItRed object with plugin metadata
	MakeItRed.init({ id, version, rootURI });
	
	// Add the plugin UI elements to all currently open Zotero windows
	MakeItRed.addToAllWindows();
	
	// Run the plugin's main functionality
	await MakeItRed.main();
}

/**
 * Called when a new Zotero window is opened

 */
function onMainWindowLoad({ window }) {
	MakeItRed.addToWindow(window);
}

/**
 * Called when a Zotero window is closed

 */
function onMainWindowUnload({ window }) {
	MakeItRed.removeFromWindow(window);
}

/**
 * Called when Zotero shuts down or when the plugin is disabled
 * Cleans up plugin resources and UI elements
 */
function shutdown() {
	log("Shutting down 2.0");
	MakeItRed.removeFromAllWindows();
	MakeItRed = undefined; // Free memory
}

/**
 * Called when the plugin is uninstalled
 */
function uninstall() {
	log("Uninstalled 2.0");
}