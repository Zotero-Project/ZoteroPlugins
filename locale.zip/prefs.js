pref("extensions.make-it-red.intensity", 100);
